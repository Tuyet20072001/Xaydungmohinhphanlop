<div class="row">
    <div class="col-12">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb mt-50">
                <li class="breadcrumb-item"><a href="/">Trang sức</a></li>
                <li class="breadcrumb-item"><a href="">bac</a></li>
                
                {{-- @foreach ($catname as $category)
                <li class="breadcrumb-item"><a href="{{ $category->cat_id }}">{{ $category->cat_name }}</a></li>
                @endforeach            
                <li class="breadcrumb-item active" aria-current="page">{{ $pro ->pro_name }}</li> --}}
            </ol>
        </nav>
    </div>