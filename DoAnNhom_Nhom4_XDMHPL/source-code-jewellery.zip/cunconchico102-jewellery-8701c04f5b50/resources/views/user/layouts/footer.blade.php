    <!-- JS Plugins -->
    <script src="{{ asset('html/user/plugins/jQuery/jquery.min.js') }}"></script>
    <script src="{{ asset('html/user/plugins/bootstrap/bootstrap.min.js') }}"></script>
    <script src="{{ asset('html/user/plugins/jquery-confirm-3.3.2/jquery-confirm.min.js') }}"></script>

    <script src="{{ asset('html/user/plugins/slick/slick.min.js') }}"></script>
    <script src="{{ asset('html/user/plugins/instafeed/instafeed.min.js') }}"></script>

    <!-- Main Script -->
    <script src="{{ asset('html/user/js/script.js') }}"></script></body>
    <script src="{{ asset('html/user/js/main.js') }}"></script></body>

</body>
</html>
