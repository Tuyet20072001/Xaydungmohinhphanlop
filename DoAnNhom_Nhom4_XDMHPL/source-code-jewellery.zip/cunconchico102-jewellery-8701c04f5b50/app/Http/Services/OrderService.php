<?php
namespace App\Http\Services;

class OrderService extends Service{

	protected $modelName = 'Order';

}